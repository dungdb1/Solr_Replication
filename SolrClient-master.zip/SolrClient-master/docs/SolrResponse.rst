SolrClient.SolrResponse module
------------------------------
SolrResponse object is returned on queries to Solr. It provides several handy methods for getting the data back. 

.. automodule:: SolrClient
.. autoclass:: SolrResponse
    :members:
    :undoc-members:
    :show-inheritance: