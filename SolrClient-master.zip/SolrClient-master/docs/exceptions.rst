SolrClient.exceptions module
----------------------------

.. automodule:: SolrClient
.. autoclass:: exceptions
    :members:
    :undoc-members:
    :show-inheritance: