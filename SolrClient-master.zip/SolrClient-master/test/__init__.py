import SolrClient
